# 🦷 DenteHub — Sistema de Agendamento e Gestão Odontológica

Sistema web full-stack desenvolvido para gerenciamento de consultas, pacientes, especialistas e bloqueios de agenda de uma clínica odontológica, com controle de acesso por perfis (**Cliente**, **Recepção** e **Administração**) e persistência em banco de dados relacional.

> **Projeto Acadêmico — Análise e Desenvolvimento de Sistemas (2º Período)**  
> **Professor:** Petros  
> **Integrantes:** Jorge Arthur, Gabriel Paes, Matheus Canejo, Erysson Roberto e Lucas Xavier

---

## ✨ Funcionalidades Principais

### 🌐 Portal Público e Área do Cliente
- **Agendamento Online em 3 Etapas:** escolha de especialidade (com sugestão automática de dentista), seleção de data e horário livre em tempo real e preenchimento dos dados do paciente.
- **Regras de Negócio Automatizadas:** bloqueio de domingos, datas passadas, agendamentos acima de 60 dias e prevenção de duplicidade de agendamento ativo para o mesmo telefone no mesmo dia.
- **Simulador Interativo (Escala Vita):** visualização interativa dos tons de clareamento dental diretamente na página inicial.
- **Protocolo e Integrações:** geração de protocolo único (`#DH-2026-XXXX`), download de evento para calendário (`.ics`) e envio de comprovante via WhatsApp.
- **Portal do Paciente:** cadastro e login para acompanhar consultas vinculadas, remarcar data/horário ou cancelar agendamentos ativos, além de busca rápida sem senha por protocolo ou telefone.

### 🏥 Área da Recepção
- **Indicadores em Tempo Real:** contagem de consultas do dia, pendentes, confirmadas e concluídas.
- **CRUD Completo de Agendamentos:** criação de encaixes presenciais, listagem com filtros (busca por nome/telefone/protocolo, data, especialista e status), **edição/remarcação completa** de dados e atualização do fluxo de atendimento (`Pendente` → `Confirmado` → `Concluído` / `Cancelado`).
- **Bloqueio de Agenda:** fechamento de dias inteiros ou horários específicos por especialista ou para toda a clínica.
- **Exportação:** download da agenda filtrada em planilha `.csv` e layout otimizado para impressão.

### 🔐 Área Administrativa
- Todas as permissões operacionais da Recepção.
- **Exclusão Definitiva:** remoção permanente de registros da base de dados.
- **Gestão de Usuários:** cadastro de novas contas para Recepção ou Administração e ativação/desativação de acessos.

---

## 🛠️ Tecnologias Utilizadas

- **Front-end:** HTML5, CSS3 (layout responsivo com alternância entre tema claro e escuro) e JavaScript (Vanilla ES6+ com Fetch API).
- **Back-end:** Python 3, **FastAPI**, **Pydantic** e **Uvicorn**.
- **Banco de Dados:** **SQLite** (`dentehub.db`) com criação automática de tabelas (`dentistas`, `usuarios`, `agendamentos`, `bloqueios`), chaves estrangeiras, índices e carga inicial de dados.
- **Segurança:** Hash de senhas com `PBKDF2-SHA256` + salt aleatório e autenticação stateless via tokens `JWT (HS256)`.

---

## 📁 Estrutura do Projeto

```text
dentehub/
├── api.py             # Servidor FastAPI, rotas REST, regras de negócio e autenticação JWT
├── banco.py           # Conexão SQLite, criação/migração de tabelas e operações CRUD
├── index.html         # Interface completa (Landing Page, Agendamento e Portais)
├── menu.py            # Menu auxiliar em terminal (opcional)
├── requirements.txt   # Dependências do projeto
├── dentehub.db        # Banco SQLite (gerado automaticamente na primeira execução)
└── README.md          # Documentação do projeto
```

---

## 🚀 Como Executar Localmente

1. **Clone ou baixe o repositório** e abra o terminal na pasta do projeto:
   ```powershell
   cd caminho\para\dentehub
   ```

2. **Instale as dependências:**
   ```powershell
   pip install -r requirements.txt
   ```

3. **Inicie o servidor:**
   ```powershell
   python api.py
   ```

4. **Acesse no navegador:**
   O navegador abrirá automaticamente em `http://127.0.0.1:8000` (documentação interativa da API disponível em `http://127.0.0.1:8000/docs`).

---

## 🔑 Contas de Teste Pré-Cadastradas

Ao iniciar o sistema pela primeira vez, o `banco.py` cria automaticamente três contas para demonstração:

| Perfil | E-mail | Senha | Permissões |
| :--- | :--- | :--- | :--- |
| **Administração** | `admin@dentehub.com` | `admin123` | Acesso total, exclusão de agendamentos e gestão de usuários |
| **Recepção** | `recepcao@dentehub.com` | `recepcao123` | Agenda, confirmação, edição/remarcação, encaixes e bloqueios |
| **Cliente** | `cliente@dentehub.com` | `cliente123` | Visualização, remarcação e cancelamento das próprias consultas |

---

## 📡 Principais Endpoints da API

| Método | Rota | Acesso | Descrição |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/slots` | Público | Lista horários livres por data e especialista |
| `POST` | `/api/agendar` | Público | Cria um novo agendamento |
| `GET` | `/api/buscar` | Público | Consulta agendamentos por protocolo ou telefone |
| `POST` | `/api/auth/login` | Público | Autentica usuário e retorna token JWT |
| `POST` | `/api/auth/register` | Público | Cadastra nova conta de cliente |
| `GET` | `/api/cliente/agendamentos` | Cliente | Lista consultas do cliente autenticado |
| `POST` | `/api/cliente/remarcar` | Cliente | Remarca data/horário de uma consulta do cliente |
| `GET` | `/api/admin/lista` | Recepção / Admin | Retorna estatísticas e agenda filtrada |
| `PUT` | `/api/admin/agendamento/{id}` | Recepção / Admin | Edita dados, data, horário, dentista ou status |
| `POST` | `/api/admin/acao` | Recepção / Admin | Altera status ou exclui registro (exclusivo Admin) |
| `GET/POST/DELETE` | `/api/admin/bloqueios` | Recepção / Admin | Gerencia bloqueios de datas e horários |
| `GET/POST` | `/api/admin/usuarios` | Admin | Lista e cria usuários da equipe |