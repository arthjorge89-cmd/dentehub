import base64
import csv
import hashlib
import hmac
import io
import json
import os
import sys
import threading
import time
import webbrowser
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import HTMLResponse, JSONResponse, Response
from pydantic import BaseModel
import uvicorn

import banco

banco.inicializar_banco()

ENDERECO = "Av. Conselheiro Aguiar, 2333, sala 1204 – Boa Viagem, Recife – PE"
JWT_SECRET = os.environ.get("DENTEHUB_JWT_SECRET", "dentehub-azul-branco-segredo-2026")
JWT_EXP_HORAS = 12
HTML_PATH = BASE_DIR / "index.html"


# --- AUTENTICAÇÃO JWT (HS256) ---


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def criar_token_jwt(usuario: dict) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    payload = {
        "sub": str(usuario["id"]),
        "nome": usuario["nome"],
        "email": usuario["email"],
        "perfil": usuario["perfil"],
        "exp": int(time.time()) + JWT_EXP_HORAS * 3600,
    }
    h_enc = _b64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    p_enc = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    msg = f"{h_enc}.{p_enc}".encode("ascii")
    sig = hmac.new(JWT_SECRET.encode("utf-8"), msg, hashlib.sha256).digest()
    return f"{h_enc}.{p_enc}.{_b64url_encode(sig)}"


def decodificar_token_jwt(token: str) -> dict | None:
    try:
        h_enc, p_enc, s_enc = token.split(".")
        msg = f"{h_enc}.{p_enc}".encode("ascii")
        sig_esperada = hmac.new(JWT_SECRET.encode("utf-8"), msg, hashlib.sha256).digest()
        if not hmac.compare_digest(_b64url_encode(sig_esperada), s_enc):
            return None
        payload = json.loads(_b64url_decode(p_enc).decode("utf-8"))
        if payload.get("exp", 0) < int(time.time()):
            return None
        return payload
    except Exception:
        return None


def get_usuario_opcional(authorization: str | None = Header(default=None)) -> dict | None:
    if not authorization or not authorization.startswith("Bearer "):
        return None
    token = authorization.split(" ", 1)[1].strip()
    payload = decodificar_token_jwt(token)
    if not payload:
        return None
    return banco.buscar_usuario_por_id(int(payload["sub"]))


def get_usuario_atual(authorization: str | None = Header(default=None)) -> dict:
    usuario = get_usuario_opcional(authorization)
    if not usuario:
        raise HTTPException(status_code=401, detail="Sessão expirada ou não autenticada.")
    return usuario


def get_equipe_atual(usuario: dict = Depends(get_usuario_atual)) -> dict:
    if usuario["perfil"] not in ("recepcao", "admin"):
        raise HTTPException(status_code=403, detail="Acesso restrito à equipe da clínica.")
    return usuario


def get_admin_atual(usuario: dict = Depends(get_usuario_atual)) -> dict:
    if usuario["perfil"] != "admin":
        raise HTTPException(status_code=403, detail="Acesso exclusivo da administração.")
    return usuario


# --- LIFESPAN E APLICAÇÃO ---


@asynccontextmanager
async def lifespan(app: FastAPI):
    banco.inicializar_banco()
    yield


app = FastAPI(
    title="DenteHub Odontologia API",
    description="Sistema de agendamento odontológico com CRUD completo e Áreas do Cliente, Recepção e Administração",
    version="6.0.0",
    lifespan=lifespan,
)


# --- MODELOS DE ENTRADA ---


class AgendamentoInput(BaseModel):
    nome: str
    tel: str
    esp: str
    dent: str = ""
    data: str
    hora: str
    conv: str = "Particular"


class EditarAgendamentoInput(BaseModel):
    nome: str
    tel: str
    esp: str
    dent: str = ""
    data: str
    hora: str
    conv: str = "Particular"
    status: str = "pendente"


class RemarcarClienteInput(BaseModel):
    id: str
    dent: str = ""
    data: str
    hora: str


class LoginInput(BaseModel):
    email: str
    senha: str


class RegistroClienteInput(BaseModel):
    nome: str
    email: str
    telefone: str
    senha: str


class AcaoInput(BaseModel):
    id: str
    acao: str


class BloqueioInput(BaseModel):
    data: str
    hora: str = ""
    dent: str = ""
    motivo: str


class NovoUsuarioInput(BaseModel):
    nome: str
    email: str
    senha: str
    perfil: str = "recepcao"
    telefone: str = ""


# --- REGRAS DE NEGÓCIO ---


def listar_horarios_dia(data_str: str) -> list[str]:
    dt = datetime.strptime(data_str, "%Y-%m-%d")
    dia_semana = dt.weekday()
    if dia_semana == 6:
        return []

    fim_minutos = 690 if dia_semana == 5 else 1110
    return [f"{m // 60:02d}:{m % 60:02d}" for m in range(480, fim_minutos + 1, 30)]


def validar_data_agendamento(data_str: str) -> str | None:
    if not data_str:
        return "Escolha uma data."
    try:
        dt = datetime.strptime(data_str, "%Y-%m-%d").date()
    except ValueError:
        return "Data inválida."

    hoje = datetime.now().date()
    if dt < hoje:
        return "Essa data já passou."
    if dt > hoje + timedelta(days=60):
        return "Agendamentos disponíveis apenas para os próximos 60 dias."
    if dt.weekday() == 6:
        return "Não atendemos aos domingos."

    motivo_bloqueio = banco.verificar_bloqueio_data_completa(data_str)
    if motivo_bloqueio:
        return f"Agenda fechada nesta data ({motivo_bloqueio})."

    return None


def dentistas_livres(
    data_str: str, hora_str: str, pool_dentistas: list[str], ignorar_id: str = ""
) -> list[str]:
    ocupados = banco.dentistas_ocupados_no_horario(data_str, hora_str, ignorar_id=ignorar_id)
    return [d for d in pool_dentistas if d not in ocupados]


# --- ROTAS PÚBLICAS ---


@app.get("/", response_class=HTMLResponse)
def index():
    if not HTML_PATH.exists():
        return HTMLResponse(
            "<h1>Erro: arquivo index.html não encontrado na pasta do projeto.</h1>",
            status_code=500,
        )
    return HTMLResponse(HTML_PATH.read_text(encoding="utf-8"))


@app.get("/api/slots")
def api_slots(
    data: str = Query(""),
    dent: str = Query(""),
    ignorar_id: str = Query(""),
):
    erro_data = validar_data_agendamento(data)
    if erro_data:
        return {"erro": erro_data, "slots": []}

    dentistas = banco.listar_dentistas()
    pool = [dent] if dent in dentistas else list(dentistas.keys())

    agora = datetime.now()
    hoje_str = agora.strftime("%Y-%m-%d")
    minuto_atual = agora.hour * 60 + agora.minute
    eh_hoje = data == hoje_str

    slots = []
    for h in listar_horarios_dia(data):
        hh, mm = map(int, h.split(":"))
        passou_hora = eh_hoje and (hh * 60 + mm <= minuto_atual)
        disponivel = (not passou_hora) and len(
            dentistas_livres(data, h, pool, ignorar_id=ignorar_id)
        ) > 0
        slots.append({"hora": h, "disponivel": disponivel})

    return {"erro": "", "slots": slots}


@app.post("/api/agendar")
def api_agendar(
    dados: AgendamentoInput,
    usuario_logado: dict | None = Depends(get_usuario_opcional),
):
    nome = " ".join(dados.nome.split())
    tel = dados.tel.strip()
    esp = dados.esp.strip()

    if len(nome.split()) < 2:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Informe nome e sobrenome."})
    if len("".join(filter(str.isdigit, tel))) != 11:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Telefone inválido. Digite os 11 dígitos."})
    if not esp:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Escolha uma especialidade."})

    erro_data = validar_data_agendamento(dados.data)
    if erro_data:
        return JSONResponse(status_code=400, content={"ok": False, "erro": erro_data})

    if dados.hora not in listar_horarios_dia(dados.data):
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Horário inválido."})

    if banco.telefone_ja_agendado_no_dia(tel, dados.data):
        return JSONResponse(
            status_code=409,
            content={"ok": False, "erro": "Já existe um agendamento ativo para este telefone nessa data."},
        )

    dentistas = banco.listar_dentistas()
    pool = [dados.dent] if dados.dent in dentistas else list(dentistas.keys())
    livres = dentistas_livres(dados.data, dados.hora, pool)

    if not livres:
        return JSONResponse(
            status_code=409,
            content={"ok": False, "erro": "Esse horário acabou de ser ocupado. Escolha outro."},
        )

    usuario_id = usuario_logado["id"] if usuario_logado and usuario_logado["perfil"] == "cliente" else None

    try:
        novo_agendamento = banco.criar_agendamento(
            nome=nome,
            tel=tel,
            esp=esp,
            dent=livres[0],
            data_str=dados.data,
            hora=dados.hora,
            conv=dados.conv or "Particular",
            usuario_id=usuario_id,
        )
    except ValueError as exc:
        return JSONResponse(status_code=409, content={"ok": False, "erro": str(exc)})

    return {"ok": True, "agendamento": novo_agendamento}


@app.get("/api/buscar")
def api_buscar(q: str = Query("")):
    return banco.buscar_agendamentos_paciente(q)


@app.post("/api/agendamento/cancelar-paciente")
def api_cancelar_paciente(dados: AcaoInput):
    ag = banco.buscar_agendamento_por_id(dados.id)
    if not ag or ag["status"] not in ("pendente", "confirmado"):
        return JSONResponse(status_code=404, content={"ok": False, "erro": "Agendamento não pode ser cancelado."})
    banco.atualizar_status_agendamento(ag["id"], "cancelado")
    return {"ok": True}


@app.get("/api/ics/{ag_id:path}")
def api_ics(ag_id: str):
    ag = banco.buscar_agendamento_por_id(ag_id)
    if not ag:
        return Response("Agendamento não encontrado.", status_code=404)

    dentistas = banco.listar_dentistas()
    nome_dentista = dentistas.get(ag["dent"], "Equipe DenteHub")

    inicio = datetime.strptime(f"{ag['data']} {ag['hora']}", "%Y-%m-%d %H:%M")
    fim = inicio + timedelta(minutes=30)
    agora_utc = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    ics_conteudo = "\r\n".join(
        [
            "BEGIN:VCALENDAR",
            "VERSION:2.0",
            "PRODID:-//DenteHub//PT-BR",
            "BEGIN:VEVENT",
            f"UID:{ag['id'].replace('#', '')}@dentehub",
            f"DTSTAMP:{agora_utc}",
            f"DTSTART:{inicio.strftime('%Y%m%dT%H%M%S')}",
            f"DTEND:{fim.strftime('%Y%m%dT%H%M%S')}",
            f"SUMMARY:Consulta DenteHub - {ag['esp']}",
            f"LOCATION:{ENDERECO.replace(',', '\\,')}",
            f"DESCRIPTION:Dentista: {nome_dentista}\\nProtocolo: {ag['id']}",
            "END:VEVENT",
            "END:VCALENDAR",
        ]
    )

    return Response(
        content=ics_conteudo,
        media_type="text/calendar",
        headers={"Content-Disposition": "attachment; filename=consulta-dentehub.ics"},
    )


# --- AUTENTICAÇÃO UNIFICADA (CLIENTE, RECEPÇÃO E ADMINISTRAÇÃO) ---


@app.post("/api/auth/login")
def api_login(dados: LoginInput):
    usuario = banco.autenticar_usuario(dados.email, dados.senha)
    if not usuario:
        return JSONResponse(
            status_code=401,
            content={"ok": False, "erro": "E-mail ou senha inválidos. Verifique os dados informados."},
        )
    token = criar_token_jwt(usuario)
    return {"ok": True, "token": token, "usuario": usuario}


@app.post("/api/auth/register")
def api_register_cliente(dados: RegistroClienteInput):
    nome = " ".join(dados.nome.split())
    if len(nome.split()) < 2:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Informe nome e sobrenome."})
    if "@" not in dados.email:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Informe um e-mail válido."})
    if len("".join(filter(str.isdigit, dados.telefone))) != 11:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Informe os 11 dígitos do WhatsApp."})
    if len(dados.senha) < 6:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "A senha deve ter no mínimo 6 caracteres."})

    try:
        novo = banco.criar_usuario(
            nome=nome,
            email=dados.email,
            senha=dados.senha,
            perfil="cliente",
            telefone=dados.telefone.strip(),
        )
        token = criar_token_jwt(novo)
        return {"ok": True, "token": token, "usuario": novo}
    except ValueError as exc:
        return JSONResponse(status_code=409, content={"ok": False, "erro": str(exc)})


@app.get("/api/auth/me")
def api_me(usuario: dict = Depends(get_usuario_atual)):
    return {"ok": True, "usuario": usuario}


# --- ÁREA DO CLIENTE ---


@app.get("/api/cliente/agendamentos")
def api_cliente_agendamentos(usuario: dict = Depends(get_usuario_atual)):
    lista = banco.listar_agendamentos_cliente(usuario["id"], usuario.get("telefone", ""))
    return {"ok": True, "usuario": usuario, "agendamentos": lista}


@app.post("/api/cliente/remarcar")
def api_cliente_remarcar(
    dados: RemarcarClienteInput,
    usuario: dict = Depends(get_usuario_atual),
):
    erro_data = validar_data_agendamento(dados.data)
    if erro_data:
        return JSONResponse(status_code=400, content={"ok": False, "erro": erro_data})

    if dados.hora not in listar_horarios_dia(dados.data):
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Horário inválido para esta data."})

    dentistas = banco.listar_dentistas()
    pool = [dados.dent] if dados.dent in dentistas else list(dentistas.keys())
    livres = dentistas_livres(dados.data, dados.hora, pool, ignorar_id=dados.id)

    if not livres:
        return JSONResponse(
            status_code=409,
            content={"ok": False, "erro": "Nenhum especialista disponível neste horário."},
        )

    try:
        atualizado = banco.remarcar_agendamento_cliente(
            ag_id=dados.id,
            usuario_id=usuario["id"],
            telefone=usuario.get("telefone", ""),
            dent=livres[0],
            data_str=dados.data,
            hora=dados.hora,
        )
        return {"ok": True, "agendamento": atualizado}
    except ValueError as exc:
        return JSONResponse(status_code=400, content={"ok": False, "erro": str(exc)})


# --- ÁREA DA RECEPÇÃO E ADMINISTRAÇÃO ---


@app.get("/api/admin/lista")
def api_admin_lista(
    data: str = Query(""),
    dent: str = Query(""),
    status: str = Query(""),
    q: str = Query(""),
    usuario: dict = Depends(get_equipe_atual),
):
    hoje_str = datetime.now().strftime("%Y-%m-%d")
    stats = banco.obter_estatisticas(hoje_str)
    lista = banco.listar_agendamentos(
        filtro_data=data, filtro_dent=dent, filtro_status=status, termo_busca=q
    )
    return {"stats": stats, "lista": lista}


@app.post("/api/admin/agendar")
def api_admin_agendar(dados: AgendamentoInput, usuario: dict = Depends(get_equipe_atual)):
    nome = " ".join(dados.nome.split())
    tel = dados.tel.strip()
    esp = dados.esp.strip()

    if len(nome.split()) < 2:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Informe nome e sobrenome."})
    if len("".join(filter(str.isdigit, tel))) != 11:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Telefone inválido."})
    if not esp or not dados.data or not dados.hora:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Preencha especialidade, data e horário."})

    dentistas = banco.listar_dentistas()
    pool = [dados.dent] if dados.dent in dentistas else list(dentistas.keys())
    livres = dentistas_livres(dados.data, dados.hora, pool)
    if not livres:
        return JSONResponse(status_code=409, content={"ok": False, "erro": "Sem profissional livre neste horário."})

    try:
        criado = banco.criar_agendamento(
            nome=nome,
            tel=tel,
            esp=esp,
            dent=livres[0],
            data_str=dados.data,
            hora=dados.hora,
            conv=dados.conv or "Particular",
        )
        return {"ok": True, "agendamento": criado}
    except ValueError as exc:
        return JSONResponse(status_code=409, content={"ok": False, "erro": str(exc)})


@app.put("/api/admin/agendamento/{ag_id:path}")
def api_admin_editar_agendamento(
    ag_id: str,
    dados: EditarAgendamentoInput,
    usuario: dict = Depends(get_equipe_atual),
):
    nome = " ".join(dados.nome.split())
    tel = dados.tel.strip()
    esp = dados.esp.strip()

    if len(nome.split()) < 2:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Informe nome e sobrenome."})
    if len("".join(filter(str.isdigit, tel))) != 11:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Telefone inválido (11 dígitos)."})
    if not esp or not dados.data or not dados.hora:
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Preencha especialidade, data e horário."})

    dentistas = banco.listar_dentistas()
    if dados.status == "cancelado":
        dent_final = dados.dent if dados.dent in dentistas else "h"
    else:
        pool = [dados.dent] if dados.dent in dentistas else list(dentistas.keys())
        livres = dentistas_livres(dados.data, dados.hora, pool, ignorar_id=ag_id)
        if not livres:
            return JSONResponse(
                status_code=409,
                content={"ok": False, "erro": "Sem especialista disponível neste dia e horário."},
            )
        dent_final = livres[0]

    try:
        editado = banco.editar_agendamento(
            ag_id=ag_id,
            nome=nome,
            tel=tel,
            esp=esp,
            dent=dent_final,
            data_str=dados.data,
            hora=dados.hora,
            conv=dados.conv or "Particular",
            status=dados.status,
        )
        return {"ok": True, "agendamento": editado}
    except ValueError as exc:
        return JSONResponse(status_code=409, content={"ok": False, "erro": str(exc)})


@app.post("/api/admin/acao")
def api_admin_acao(dados: AcaoInput, usuario: dict = Depends(get_equipe_atual)):
    if dados.acao == "del":
        if usuario["perfil"] != "admin":
            return JSONResponse(
                status_code=403,
                content={"ok": False, "erro": "Apenas a Administração pode excluir registros."},
            )
        sucesso = banco.excluir_agendamento(dados.id)
    else:
        sucesso = banco.atualizar_status_agendamento(dados.id, dados.acao)

    if not sucesso:
        return JSONResponse(status_code=404, content={"ok": False, "erro": "Agendamento não encontrado."})
    return {"ok": True}


@app.get("/api/admin/bloqueios")
def api_admin_listar_bloqueios(usuario: dict = Depends(get_equipe_atual)):
    return banco.listar_bloqueios()


@app.post("/api/admin/bloqueios")
def api_admin_criar_bloqueio(dados: BloqueioInput, usuario: dict = Depends(get_equipe_atual)):
    if not dados.data or not dados.motivo.strip():
        return JSONResponse(status_code=400, content={"ok": False, "erro": "Informe a data e o motivo."})
    criado = banco.criar_bloqueio(dados.data, dados.hora, dados.dent, dados.motivo)
    return {"ok": True, "bloqueio": criado}


@app.delete("/api/admin/bloqueios/{bloqueio_id}")
def api_admin_remover_bloqueio(bloqueio_id: int, usuario: dict = Depends(get_equipe_atual)):
    if not banco.remover_bloqueio(bloqueio_id):
        return JSONResponse(status_code=404, content={"ok": False, "erro": "Bloqueio não encontrado."})
    return {"ok": True}


@app.get("/api/admin/usuarios")
def api_admin_usuarios(usuario: dict = Depends(get_admin_atual)):
    return banco.listar_usuarios()


@app.post("/api/admin/usuarios")
def api_admin_criar_usuario(dados: NovoUsuarioInput, usuario: dict = Depends(get_admin_atual)):
    if len(dados.nome.strip()) < 3 or "@" not in dados.email or len(dados.senha) < 6:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "erro": "Preencha nome, e-mail válido e senha com no mínimo 6 caracteres."},
        )
    try:
        criado = banco.criar_usuario(dados.nome, dados.email, dados.senha, dados.perfil, dados.telefone)
        return {"ok": True, "usuario": criado}
    except ValueError as exc:
        return JSONResponse(status_code=409, content={"ok": False, "erro": str(exc)})


@app.post("/api/admin/usuarios/{user_id}/toggle")
def api_admin_toggle_usuario(user_id: int, usuario: dict = Depends(get_admin_atual)):
    if user_id == usuario["id"]:
        return JSONResponse(
            status_code=400,
            content={"ok": False, "erro": "Você não pode desativar sua própria conta."},
        )
    if not banco.alternar_ativo_usuario(user_id):
        return JSONResponse(status_code=404, content={"ok": False, "erro": "Usuário não encontrado."})
    return {"ok": True}


@app.get("/api/admin/exportar-csv")
def api_admin_exportar_csv(
    data: str = Query(""),
    dent: str = Query(""),
    status: str = Query(""),
    q: str = Query(""),
    usuario: dict = Depends(get_equipe_atual),
):
    lista = banco.listar_agendamentos(
        filtro_data=data, filtro_dent=dent, filtro_status=status, termo_busca=q
    )
    dentistas = banco.listar_dentistas()

    output = io.StringIO()
    writer = csv.writer(output, delimiter=";")
    writer.writerow(["Protocolo", "Paciente", "Telefone", "Especialidade", "Dentista", "Data", "Hora", "Convênio", "Status"])

    for a in lista:
        writer.writerow([
            a["id"],
            a["nome"],
            a["tel"],
            a["esp"],
            dentistas.get(a["dent"], a["dent"]),
            a["data"],
            a["hora"],
            a["conv"],
            a["status"].upper(),
        ])

    conteudo_csv = "\ufeff" + output.getvalue()
    return Response(
        content=conteudo_csv.encode("utf-8"),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=agendamentos-dentehub.csv"},
    )


if __name__ == "__main__":
    threading.Timer(1.0, lambda: webbrowser.open("http://127.0.0.1:8000")).start()
    uvicorn.run(app, host="0.0.0.0", port=8000)