import hashlib
import hmac
import os
import random
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent / "dentehub.db"


def conectar() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def hash_senha(senha: str) -> str:
    salt = os.urandom(16).hex()
    dk = hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), salt.encode("utf-8"), 100_000)
    return f"{salt}${dk.hex()}"


def verificar_senha(senha: str, senha_hash: str) -> bool:
    try:
        salt, hash_armazenado = senha_hash.split("$", 1)
    except ValueError:
        return False
    dk = hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), salt.encode("utf-8"), 100_000)
    return hmac.compare_digest(dk.hex(), hash_armazenado)


def proximo_dia_util(data_base: datetime) -> datetime:
    while data_base.weekday() == 6:  # 6 = Domingo
        data_base += timedelta(days=1)
    return data_base


def _migrar_tabela_usuarios_se_necessario(conn: sqlite3.Connection) -> None:
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='usuarios';"
    ).fetchone()
    if not row:
        return

    sql_atual = (row["sql"] or "").lower()
    if "'cliente'" not in sql_atual or "telefone" not in sql_atual:
        colunas_info = conn.execute("PRAGMA table_info(usuarios);").fetchall()
        nomes_colunas = {c["name"] for c in colunas_info}
        usuarios_antigos = conn.execute("SELECT * FROM usuarios;").fetchall()

        conn.execute("DROP TABLE usuarios;")
        conn.execute("""
            CREATE TABLE usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                telefone TEXT NOT NULL DEFAULT '',
                senha_hash TEXT NOT NULL,
                perfil TEXT NOT NULL CHECK (perfil IN ('admin', 'recepcao', 'cliente')),
                ativo INTEGER NOT NULL DEFAULT 1,
                criado_em TEXT NOT NULL
            );
        """)

        for u in usuarios_antigos:
            tel = u["telefone"] if "telefone" in nomes_colunas else ""
            perfil = u["perfil"] if u["perfil"] in ("admin", "recepcao", "cliente") else "recepcao"
            conn.execute(
                """
                INSERT OR IGNORE INTO usuarios (id, nome, email, telefone, senha_hash, perfil, ativo, criado_em)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                """,
                (
                    u["id"],
                    u["nome"],
                    u["email"],
                    tel or "",
                    u["senha_hash"],
                    perfil,
                    u["ativo"],
                    u["criado_em"],
                ),
            )


def inicializar_banco() -> None:
    with conectar() as conn:
        _migrar_tabela_usuarios_se_necessario(conn)

        conn.executescript("""
            CREATE TABLE IF NOT EXISTS dentistas (
                id TEXT PRIMARY KEY,
                nome TEXT NOT NULL,
                especialidade TEXT NOT NULL,
                cro TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                telefone TEXT NOT NULL DEFAULT '',
                senha_hash TEXT NOT NULL,
                perfil TEXT NOT NULL CHECK (perfil IN ('admin', 'recepcao', 'cliente')),
                ativo INTEGER NOT NULL DEFAULT 1,
                criado_em TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS agendamentos (
                id TEXT PRIMARY KEY,
                nome TEXT NOT NULL,
                tel TEXT NOT NULL,
                esp TEXT NOT NULL,
                dent TEXT NOT NULL,
                data TEXT NOT NULL,
                hora TEXT NOT NULL,
                conv TEXT NOT NULL DEFAULT 'Particular',
                status TEXT NOT NULL DEFAULT 'pendente'
                    CHECK (status IN ('pendente', 'confirmado', 'concluido', 'cancelado')),
                usuario_id INTEGER,
                criado_em TEXT NOT NULL,
                FOREIGN KEY (dent) REFERENCES dentistas(id)
            );

            CREATE TABLE IF NOT EXISTS bloqueios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                data TEXT NOT NULL,
                hora TEXT NOT NULL DEFAULT '',
                dent TEXT NOT NULL DEFAULT '',
                motivo TEXT NOT NULL,
                criado_em TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_agendamentos_data_hora
                ON agendamentos (data, hora);

            CREATE INDEX IF NOT EXISTS idx_bloqueios_data
                ON bloqueios (data);
        """)

        cols_ag = {c["name"] for c in conn.execute("PRAGMA table_info(agendamentos);").fetchall()}
        if "usuario_id" not in cols_ag:
            conn.execute("ALTER TABLE agendamentos ADD COLUMN usuario_id INTEGER;")

        agora_iso = datetime.now().isoformat(timespec="seconds")

        dentistas_iniciais = [
            ("h", "Dra. Helena Aguiar", "Implantodontia e Estética", "CRO-PE 12480"),
            ("r", "Dr. Rafael Moura", "Ortodontia Digital", "CRO-PE 11932"),
            ("l", "Dra. Letícia Campos", "Odontopediatria e Prevenção", "CRO-PE 13207"),
        ]
        conn.executemany(
            "INSERT OR IGNORE INTO dentistas (id, nome, especialidade, cro) VALUES (?, ?, ?, ?);",
            dentistas_iniciais,
        )

        contas_padrao = [
            ("Diretoria DenteHub", "admin@dentehub.com", "(81) 3042-1180", "admin123", "admin"),
            ("Recepção Central", "recepcao@dentehub.com", "(81) 99100-2000", "recepcao123", "recepcao"),
            ("Mariana Souza", "cliente@dentehub.com", "(81) 99812-3456", "cliente123", "cliente"),
        ]
        for nome, email, telefone, senha_plana, perfil in contas_padrao:
            existe = conn.execute(
                "SELECT id FROM usuarios WHERE email = ?;", (email,)
            ).fetchone()
            if not existe:
                conn.execute(
                    """
                    INSERT INTO usuarios (nome, email, telefone, senha_hash, perfil, ativo, criado_em)
                    VALUES (?, ?, ?, ?, ?, 1, ?);
                    """,
                    (nome, email, telefone, hash_senha(senha_plana), perfil, agora_iso),
                )

        total_ag = conn.execute("SELECT COUNT(*) FROM agendamentos;").fetchone()[0]
        if total_ag == 0:
            hoje = proximo_dia_util(datetime.now())
            amanha = proximo_dia_util(hoje + timedelta(days=1))
            cli_row = conn.execute(
                "SELECT id FROM usuarios WHERE email = 'cliente@dentehub.com';"
            ).fetchone()
            cli_id = cli_row["id"] if cli_row else None

            exemplos = [
                (
                    "#DH-2026-4821",
                    "Mariana Souza",
                    "(81) 99812-3456",
                    "Clareamento",
                    "h",
                    hoje.strftime("%Y-%m-%d"),
                    "09:00",
                    "Particular",
                    "confirmado",
                    cli_id,
                    agora_iso,
                ),
                (
                    "#DH-2026-3307",
                    "Carlos Eduardo Lima",
                    "(81) 99644-7821",
                    "Ortodontia",
                    "r",
                    hoje.strftime("%Y-%m-%d"),
                    "10:30",
                    "OdontoPrev",
                    "pendente",
                    None,
                    agora_iso,
                ),
                (
                    "#DH-2026-7215",
                    "Patrícia Lemos",
                    "(81) 98733-0912",
                    "Odontopediatria",
                    "l",
                    amanha.strftime("%Y-%m-%d"),
                    "14:00",
                    "Bradesco Dental",
                    "pendente",
                    None,
                    agora_iso,
                ),
            ]
            conn.executemany(
                """
                INSERT INTO agendamentos (id, nome, tel, esp, dent, data, hora, conv, status, usuario_id, criado_em)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """,
                exemplos,
            )


# --- USUÁRIOS E AUTENTICAÇÃO ---


def autenticar_usuario(email: str, senha: str) -> dict | None:
    email_limpo = email.strip().lower()
    with conectar() as conn:
        row = conn.execute(
            "SELECT * FROM usuarios WHERE email = ?;", (email_limpo,)
        ).fetchone()
        if not row or not row["ativo"]:
            return None
        if not verificar_senha(senha, row["senha_hash"]):
            return None
        return {
            "id": row["id"],
            "nome": row["nome"],
            "email": row["email"],
            "telefone": row["telefone"] or "",
            "perfil": row["perfil"],
            "ativo": bool(row["ativo"]),
        }


def buscar_usuario_por_id(user_id: int) -> dict | None:
    with conectar() as conn:
        row = conn.execute(
            "SELECT id, nome, email, telefone, perfil, ativo FROM usuarios WHERE id = ?;",
            (user_id,),
        ).fetchone()
        if not row or not row["ativo"]:
            return None
        return {
            "id": row["id"],
            "nome": row["nome"],
            "email": row["email"],
            "telefone": row["telefone"] or "",
            "perfil": row["perfil"],
            "ativo": bool(row["ativo"]),
        }


def listar_usuarios() -> list[dict]:
    with conectar() as conn:
        rows = conn.execute(
            "SELECT id, nome, email, telefone, perfil, ativo, criado_em FROM usuarios ORDER BY id ASC;"
        ).fetchall()
        return [dict(r) for r in rows]


def criar_usuario(
    nome: str, email: str, senha: str, perfil: str = "recepcao", telefone: str = ""
) -> dict:
    if perfil not in ("admin", "recepcao", "cliente"):
        raise ValueError("Perfil de acesso inválido.")
    email_limpo = email.strip().lower()
    criado_em = datetime.now().isoformat(timespec="seconds")

    with conectar() as conn:
        existe = conn.execute(
            "SELECT 1 FROM usuarios WHERE email = ?;", (email_limpo,)
        ).fetchone()
        if existe:
            raise ValueError("Já existe uma conta cadastrada com este e-mail.")

        cur = conn.execute(
            """
            INSERT INTO usuarios (nome, email, telefone, senha_hash, perfil, ativo, criado_em)
            VALUES (?, ?, ?, ?, ?, 1, ?);
            """,
            (nome.strip(), email_limpo, telefone.strip(), hash_senha(senha), perfil, criado_em),
        )
        row = conn.execute(
            "SELECT id, nome, email, telefone, perfil, ativo, criado_em FROM usuarios WHERE id = ?;",
            (cur.lastrowid,),
        ).fetchone()
        return dict(row)


def alternar_ativo_usuario(user_id: int) -> bool:
    with conectar() as conn:
        cur = conn.execute(
            "UPDATE usuarios SET ativo = CASE WHEN ativo = 1 THEN 0 ELSE 1 END WHERE id = ?;",
            (user_id,),
        )
        return cur.rowcount > 0


# --- BLOQUEIOS DE AGENDA ---


def listar_bloqueios() -> list[dict]:
    with conectar() as conn:
        rows = conn.execute(
            "SELECT * FROM bloqueios ORDER BY data ASC, hora ASC;"
        ).fetchall()
        return [dict(r) for r in rows]


def criar_bloqueio(data_str: str, hora: str, dent: str, motivo: str) -> dict:
    criado_em = datetime.now().isoformat(timespec="seconds")
    with conectar() as conn:
        cur = conn.execute(
            """
            INSERT INTO bloqueios (data, hora, dent, motivo, criado_em)
            VALUES (?, ?, ?, ?, ?);
            """,
            (data_str, hora.strip(), dent.strip(), motivo.strip(), criado_em),
        )
        row = conn.execute(
            "SELECT * FROM bloqueios WHERE id = ?;", (cur.lastrowid,)
        ).fetchone()
        return dict(row)


def remover_bloqueio(bloqueio_id: int) -> bool:
    with conectar() as conn:
        cur = conn.execute("DELETE FROM bloqueios WHERE id = ?;", (bloqueio_id,))
        return cur.rowcount > 0


def verificar_bloqueio_data_completa(data_str: str) -> str | None:
    with conectar() as conn:
        row = conn.execute(
            """
            SELECT motivo FROM bloqueios
            WHERE data = ? AND hora = '' AND dent = ''
            LIMIT 1;
            """,
            (data_str,),
        ).fetchone()
        return row["motivo"] if row else None


# --- DENTISTAS E AGENDAMENTOS (CRUD COMPLETO) ---


def listar_dentistas() -> dict[str, str]:
    with conectar() as conn:
        rows = conn.execute("SELECT id, nome FROM dentistas ORDER BY nome;").fetchall()
        return {row["id"]: row["nome"] for row in rows}


def dentistas_ocupados_no_horario(
    data_str: str, hora_str: str, ignorar_id: str = ""
) -> set[str]:
    ignorar_fmt = f"#{ignorar_id.strip().lstrip('#').upper()}" if ignorar_id.strip() else ""
    with conectar() as conn:
        if ignorar_fmt:
            rows = conn.execute(
                """
                SELECT dent FROM agendamentos
                WHERE data = ? AND hora = ? AND status != 'cancelado' AND id != ?;
                """,
                (data_str, hora_str, ignorar_fmt),
            ).fetchall()
        else:
            rows = conn.execute(
                """
                SELECT dent FROM agendamentos
                WHERE data = ? AND hora = ? AND status != 'cancelado';
                """,
                (data_str, hora_str),
            ).fetchall()
        ocupados = {row["dent"] for row in rows}

        bloqueios = conn.execute(
            """
            SELECT dent FROM bloqueios
            WHERE data = ? AND (hora = '' OR hora = ?);
            """,
            (data_str, hora_str),
        ).fetchall()

        if any(b["dent"] == "" for b in bloqueios):
            todos = conn.execute("SELECT id FROM dentistas;").fetchall()
            ocupados.update(d["id"] for d in todos)
        else:
            ocupados.update(b["dent"] for b in bloqueios if b["dent"])

        return ocupados


def telefone_ja_agendado_no_dia(tel: str, data_str: str) -> bool:
    digitos_novo = "".join(filter(str.isdigit, tel))
    if len(digitos_novo) < 8:
        return False

    with conectar() as conn:
        rows = conn.execute(
            """
            SELECT tel FROM agendamentos
            WHERE data = ? AND status IN ('pendente', 'confirmado');
            """,
            (data_str,),
        ).fetchall()

    for row in rows:
        digitos_exist = "".join(filter(str.isdigit, row["tel"]))
        if digitos_exist.endswith(digitos_novo[-9:]):
            return True
    return False


def gerar_protocolo_unico(conn: sqlite3.Connection, ano: int) -> str:
    while True:
        candidato = f"#DH-{ano}-{random.randint(1000, 9999)}"
        existe = conn.execute(
            "SELECT 1 FROM agendamentos WHERE id = ?;", (candidato,)
        ).fetchone()
        if not existe:
            return candidato


def criar_agendamento(
    nome: str,
    tel: str,
    esp: str,
    dent: str,
    data_str: str,
    hora: str,
    conv: str = "Particular",
    usuario_id: int | None = None,
) -> dict:
    with conectar() as conn:
        conflito = conn.execute(
            """
            SELECT 1 FROM agendamentos
            WHERE data = ? AND hora = ? AND dent = ? AND status != 'cancelado';
            """,
            (data_str, hora, dent),
        ).fetchone()
        if conflito:
            raise ValueError("Esse horário acabou de ser ocupado. Escolha outro.")

        bloqueado = conn.execute(
            """
            SELECT 1 FROM bloqueios
            WHERE data = ? AND (hora = '' OR hora = ?) AND (dent = '' OR dent = ?);
            """,
            (data_str, hora, dent),
        ).fetchone()
        if bloqueado:
            raise ValueError("Horário bloqueado pela administração da clínica.")

        novo_id = gerar_protocolo_unico(conn, datetime.now().year)
        criado_em = datetime.now().isoformat(timespec="seconds")

        conn.execute(
            """
            INSERT INTO agendamentos (id, nome, tel, esp, dent, data, hora, conv, status, usuario_id, criado_em)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pendente', ?, ?);
            """,
            (novo_id, nome, tel, esp, dent, data_str, hora, conv, usuario_id, criado_em),
        )

        row = conn.execute(
            "SELECT * FROM agendamentos WHERE id = ?;", (novo_id,)
        ).fetchone()
        return dict(row)


def editar_agendamento(
    ag_id: str,
    nome: str,
    tel: str,
    esp: str,
    dent: str,
    data_str: str,
    hora: str,
    conv: str,
    status: str,
) -> dict:
    ag_id_fmt = f"#{ag_id.strip().lstrip('#').upper()}"
    if status not in ("pendente", "confirmado", "concluido", "cancelado"):
        raise ValueError("Situação de agendamento inválida.")

    with conectar() as conn:
        existente = conn.execute(
            "SELECT * FROM agendamentos WHERE id = ?;", (ag_id_fmt,)
        ).fetchone()
        if not existente:
            raise ValueError("Agendamento não encontrado.")

        if status != "cancelado":
            conflito = conn.execute(
                """
                SELECT 1 FROM agendamentos
                WHERE data = ? AND hora = ? AND dent = ?
                  AND status != 'cancelado' AND id != ?;
                """,
                (data_str, hora, dent, ag_id_fmt),
            ).fetchone()
            if conflito:
                raise ValueError("Este especialista já possui outro atendimento neste dia e horário.")

            bloqueado = conn.execute(
                """
                SELECT 1 FROM bloqueios
                WHERE data = ? AND (hora = '' OR hora = ?) AND (dent = '' OR dent = ?);
                """,
                (data_str, hora, dent),
            ).fetchone()
            if bloqueado:
                raise ValueError("Horário bloqueado pela administração da clínica.")

        conn.execute(
            """
            UPDATE agendamentos
            SET nome = ?, tel = ?, esp = ?, dent = ?, data = ?, hora = ?, conv = ?, status = ?
            WHERE id = ?;
            """,
            (nome, tel, esp, dent, data_str, hora, conv, status, ag_id_fmt),
        )
        row = conn.execute(
            "SELECT * FROM agendamentos WHERE id = ?;", (ag_id_fmt,)
        ).fetchone()
        return dict(row)


def remarcar_agendamento_cliente(
    ag_id: str,
    usuario_id: int,
    telefone: str,
    dent: str,
    data_str: str,
    hora: str,
) -> dict:
    ag_id_fmt = f"#{ag_id.strip().lstrip('#').upper()}"
    digitos = "".join(filter(str.isdigit, telefone))
    sufixo = digitos[-9:] if len(digitos) >= 8 else ""

    with conectar() as conn:
        row = conn.execute(
            "SELECT * FROM agendamentos WHERE id = ?;", (ag_id_fmt,)
        ).fetchone()
        if not row:
            raise ValueError("Agendamento não encontrado.")

        tel_item = "".join(filter(str.isdigit, row["tel"]))
        pertence = (row["usuario_id"] == usuario_id) or (bool(sufixo) and tel_item.endswith(sufixo))
        if not pertence:
            raise ValueError("Você não tem permissão para remarcar este agendamento.")

        if row["status"] not in ("pendente", "confirmado"):
            raise ValueError("Apenas consultas pendentes ou confirmadas podem ser remarcadas.")

        conflito = conn.execute(
            """
            SELECT 1 FROM agendamentos
            WHERE data = ? AND hora = ? AND dent = ?
              AND status != 'cancelado' AND id != ?;
            """,
            (data_str, hora, dent, ag_id_fmt),
        ).fetchone()
        if conflito:
            raise ValueError("Esse horário acabou de ser ocupado. Escolha outro.")

        bloqueado = conn.execute(
            """
            SELECT 1 FROM bloqueios
            WHERE data = ? AND (hora = '' OR hora = ?) AND (dent = '' OR dent = ?);
            """,
            (data_str, hora, dent),
        ).fetchone()
        if bloqueado:
            raise ValueError("Horário bloqueado na agenda da clínica.")

        conn.execute(
            """
            UPDATE agendamentos
            SET dent = ?, data = ?, hora = ?, status = 'pendente'
            WHERE id = ?;
            """,
            (dent, data_str, hora, ag_id_fmt),
        )
        atualizado = conn.execute(
            "SELECT * FROM agendamentos WHERE id = ?;", (ag_id_fmt,)
        ).fetchone()
        return dict(atualizado)


def listar_agendamentos(
    filtro_data: str = "",
    filtro_dent: str = "",
    filtro_status: str = "",
    termo_busca: str = "",
) -> list[dict]:
    query = "SELECT * FROM agendamentos WHERE 1=1"
    params = []

    if filtro_data:
        query += " AND data = ?"
        params.append(filtro_data)
    if filtro_dent:
        query += " AND dent = ?"
        params.append(filtro_dent)
    if filtro_status:
        query += " AND status = ?"
        params.append(filtro_status)
    if termo_busca.strip():
        like = f"%{termo_busca.strip()}%"
        query += " AND (nome LIKE ? OR tel LIKE ? OR id LIKE ?)"
        params.extend([like, like, like])

    query += " ORDER BY data ASC, hora ASC;"

    with conectar() as conn:
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]


def listar_agendamentos_cliente(usuario_id: int, telefone: str) -> list[dict]:
    digitos = "".join(filter(str.isdigit, telefone))
    sufixo = digitos[-9:] if len(digitos) >= 8 else ""

    with conectar() as conn:
        rows = conn.execute(
            "SELECT * FROM agendamentos ORDER BY data DESC, hora DESC;"
        ).fetchall()

    resultado = []
    for r in rows:
        item = dict(r)
        tel_item = "".join(filter(str.isdigit, item["tel"]))
        mesmo_usuario = item.get("usuario_id") == usuario_id
        mesmo_telefone = bool(sufixo) and tel_item.endswith(sufixo)
        if mesmo_usuario or mesmo_telefone:
            resultado.append(item)
    return resultado


def buscar_agendamento_por_id(ag_id: str) -> dict | None:
    ag_id_fmt = f"#{ag_id.strip().lstrip('#').upper()}"
    with conectar() as conn:
        row = conn.execute(
            "SELECT * FROM agendamentos WHERE id = ?;", (ag_id_fmt,)
        ).fetchone()
        return dict(row) if row else None


def buscar_agendamentos_paciente(termo: str) -> list[dict]:
    q = termo.strip()
    if not q:
        return []

    digitos = "".join(filter(str.isdigit, q))
    proto = f"#{q.upper().lstrip('#')}"

    with conectar() as conn:
        rows = conn.execute(
            "SELECT * FROM agendamentos ORDER BY data DESC, hora DESC;"
        ).fetchall()

    resultados = []
    for r in rows:
        item = dict(r)
        tel_limpo = "".join(filter(str.isdigit, item["tel"]))
        if item["id"] == proto or (len(digitos) >= 8 and tel_limpo.endswith(digitos)):
            resultados.append(item)
    return resultados


def atualizar_status_agendamento(ag_id: str, novo_status: str) -> bool:
    if novo_status not in ("pendente", "confirmado", "concluido", "cancelado"):
        return False
    ag_id_fmt = f"#{ag_id.strip().lstrip('#').upper()}"
    with conectar() as conn:
        cur = conn.execute(
            "UPDATE agendamentos SET status = ? WHERE id = ?;",
            (novo_status, ag_id_fmt),
        )
        return cur.rowcount > 0


def excluir_agendamento(ag_id: str) -> bool:
    ag_id_fmt = f"#{ag_id.strip().lstrip('#').upper()}"
    with conectar() as conn:
        cur = conn.execute("DELETE FROM agendamentos WHERE id = ?;", (ag_id_fmt,))
        return cur.rowcount > 0


def obter_estatisticas(hoje_str: str) -> dict:
    with conectar() as conn:
        hoje = conn.execute(
            "SELECT COUNT(*) FROM agendamentos WHERE data = ? AND status != 'cancelado';",
            (hoje_str,),
        ).fetchone()[0]
        pendentes = conn.execute(
            "SELECT COUNT(*) FROM agendamentos WHERE status = 'pendente';"
        ).fetchone()[0]
        confirmados = conn.execute(
            "SELECT COUNT(*) FROM agendamentos WHERE status = 'confirmado';"
        ).fetchone()[0]
        concluidos = conn.execute(
            "SELECT COUNT(*) FROM agendamentos WHERE status = 'concluido';"
        ).fetchone()[0]
        total = conn.execute("SELECT COUNT(*) FROM agendamentos;").fetchone()[0]

    return {
        "hoje": hoje,
        "pendentes": pendentes,
        "confirmados": confirmados,
        "concluidos": concluidos,
        "total": total,
    }