import os
import sys
import threading
import webbrowser
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

import uvicorn

import api
import banco


def limpar_tela():
    os.system("cls" if os.name == "nt" else "clear")


def pausar():
    input("\nPressione ENTER para continuar...")


def formatar_data_br(data_iso: str) -> str:
    try:
        return datetime.strptime(data_iso, "%Y-%m-%d").strftime("%d/%m/%Y")
    except ValueError:
        return data_iso


def exibir_tabela(agendamentos: list[dict]):
    dentistas = banco.listar_dentistas()
    if not agendamentos:
        print("\nNenhum agendamento encontrado.")
        return

    print("\n" + "-" * 96)
    print(
        f"{'PROTOCOLO':<15} | {'PACIENTE':<22} | {'ESPECIALIDADE':<18} | "
        f"{'DATA/HORA':<16} | {'STATUS':<11}"
    )
    print("-" * 96)
    for a in agendamentos:
        data_hora = f"{formatar_data_br(a['data'])} {a['hora']}"
        nome_dent = dentistas.get(a["dent"], a["dent"])
        print(
            f"{a['id']:<15} | {a['nome'][:22]:<22} | {a['esp'][:18]:<18} | "
            f"{data_hora:<16} | {a['status'].upper():<11}"
        )
        print(f"   Tel: {a['tel']} | Convênio: {a['conv']} | Profissional: {nome_dent}")
    print("-" * 96)


def opcao_listar():
    print("\n=== LISTAR AGENDAMENTOS ===")
    data = input("Filtrar por data (AAAA-MM-DD ou ENTER para todas): ").strip()
    dent = input("Filtrar por dentista [h=Helena, r=Rafael, l=Letícia ou ENTER]: ").strip().lower()
    status = input("Filtrar por status [pendente/confirmado/concluido/cancelado ou ENTER]: ").strip().lower()
    exibir_tabela(banco.listar_agendamentos(filtro_data=data, filtro_dent=dent, filtro_status=status))


def opcao_buscar():
    print("\n=== BUSCAR AGENDAMENTO ===")
    termo = input("Digite o protocolo (ex: DH-2026-4821) ou telefone: ").strip()
    exibir_tabela(banco.buscar_agendamentos_paciente(termo))


def opcao_novo_agendamento():
    print("\n=== NOVO AGENDAMENTO ===")
    nome = " ".join(input("Nome completo do paciente: ").split())
    if len(nome.split()) < 2:
        print("Erro: informe nome e sobrenome.")
        return

    tel = input("Telefone com DDD (ex: (81) 99999-9999): ").strip()
    if len("".join(filter(str.isdigit, tel))) != 11:
        print("Erro: informe os 11 dígitos do telefone.")
        return

    especialidades = [
        "Avaliação geral",
        "Clareamento",
        "Implantes",
        "Ortodontia",
        "Limpeza e prevenção",
        "Odontopediatria",
        "Urgência",
    ]
    for idx, item in enumerate(especialidades, 1):
        print(f"  {idx}. {item}")

    try:
        esp = especialidades[int(input("Escolha o número da especialidade: ").strip()) - 1]
    except (ValueError, IndexError):
        print("Erro: especialidade inválida.")
        return

    dentistas = banco.listar_dentistas()
    for k, v in dentistas.items():
        print(f"  [{k}] {v}")
    dent_pref = input("Código do dentista (ou ENTER para sem preferência): ").strip().lower()

    data_str = input("Data da consulta (AAAA-MM-DD): ").strip()
    erro_data = api.validar_data_agendamento(data_str)
    if erro_data:
        print(f"Erro: {erro_data}")
        return

    pool = [dent_pref] if dent_pref in dentistas else list(dentistas.keys())
    horarios_livres = [
        h for h in api.listar_horarios_dia(data_str)
        if len(api.dentistas_livres(data_str, h, pool)) > 0
    ]
    if not horarios_livres:
        print("Nenhum horário disponível para essa data.")
        return

    print("Horários disponíveis:", ", ".join(horarios_livres))
    hora = input("Escolha o horário (HH:MM): ").strip()
    if hora not in horarios_livres:
        print("Erro: horário indisponível ou inválido.")
        return

    conv = input("Convênio [ENTER para Particular]: ").strip() or "Particular"
    livres = api.dentistas_livres(data_str, hora, pool)

    try:
        criado = banco.criar_agendamento(nome, tel, esp, livres[0], data_str, hora, conv)
        print(f"\nAgendamento criado com sucesso! Protocolo: {criado['id']}")
    except ValueError as exc:
        print(f"Erro: {exc}")


def opcao_alterar_status():
    print("\n=== ALTERAR STATUS ===")
    ag = banco.buscar_agendamento_por_id(input("Informe o protocolo: ").strip())
    if not ag:
        print("Agendamento não encontrado.")
        return
    print(f"Paciente: {ag['nome']} | Status atual: {ag['status'].upper()}")
    mapa = {"1": "confirmado", "2": "concluido", "3": "cancelado", "4": "pendente"}
    escolha = input("[1] Confirmado  [2] Concluído  [3] Cancelado  [4] Pendente: ").strip()
    if escolha in mapa and banco.atualizar_status_agendamento(ag["id"], mapa[escolha]):
        print(f"Status atualizado para {mapa[escolha].upper()}.")
    else:
        print("Opção inválida.")


def opcao_excluir():
    print("\n=== EXCLUIR AGENDAMENTO ===")
    ag = banco.buscar_agendamento_por_id(input("Informe o protocolo a excluir: ").strip())
    if not ag:
        print("Agendamento não encontrado.")
        return
    if input(f"Excluir {ag['id']} ({ag['nome']})? [s/N]: ").strip().lower() == "s":
        banco.excluir_agendamento(ag["id"])
        print("Agendamento removido.")


def opcao_usuarios():
    print("\n=== USUÁRIOS DO SISTEMA ===")
    for u in banco.listar_usuarios():
        status = "ATIVO" if u["ativo"] else "INATIVO"
        print(f"  ID {u['id']} | {u['nome']} | {u['email']} | Perfil: {u['perfil'].upper()} | {status}")

    if input("\nCadastrar novo usuário? [s/N]: ").strip().lower() == "s":
        nome = input("Nome: ").strip()
        email = input("E-mail: ").strip()
        senha = input("Senha (mín. 6 caracteres): ").strip()
        perfil = input("Perfil [admin/recepcao]: ").strip().lower() or "recepcao"
        try:
            novo = banco.criar_usuario(nome, email, senha, perfil)
            print(f"Usuário {novo['email']} criado com sucesso!")
        except ValueError as exc:
            print(f"Erro: {exc}")


def opcao_estatisticas():
    hoje_str = datetime.now().strftime("%Y-%m-%d")
    st = banco.obter_estatisticas(hoje_str)
    print("\n=== RESUMO DA CLÍNICA DENTEHUB ===")
    print(f"Consultas hoje ({formatar_data_br(hoje_str)}): {st['hoje']}")
    print(f"Pendentes:   {st['pendentes']}")
    print(f"Confirmados: {st['confirmados']}")
    print(f"Concluídos:  {st['concluidos']}")
    print(f"Total geral: {st['total']}")


def iniciar_servidor():
    print("\nIniciando servidor FastAPI em http://127.0.0.1:8000 ...")
    print("Documentação Swagger: http://127.0.0.1:8000/docs")
    threading.Timer(1.0, lambda: webbrowser.open("http://127.0.0.1:8000")).start()
    uvicorn.run(api.app, host="0.0.0.0", port=8000)


def main():
    banco.inicializar_banco()
    while True:
        limpar_tela()
        print("==========================================")
        print("       DENTEHUB - SISTEMA DE GESTÃO       ")
        print("==========================================")
        print("1. Listar agendamentos")
        print("2. Buscar agendamento (protocolo/telefone)")
        print("3. Novo agendamento")
        print("4. Alterar status (confirmar/concluir/cancelar)")
        print("5. Excluir agendamento")
        print("6. Gerenciar usuários (Admin/Recepção)")
        print("7. Estatísticas da clínica")
        print("8. Iniciar servidor Web + API (FastAPI)")
        print("0. Sair")
        print("==========================================")

        opcao = input("Escolha uma opção: ").strip()

        if opcao == "1":
            opcao_listar()
            pausar()
        elif opcao == "2":
            opcao_buscar()
            pausar()
        elif opcao == "3":
            opcao_novo_agendamento()
            pausar()
        elif opcao == "4":
            opcao_alterar_status()
            pausar()
        elif opcao == "5":
            opcao_excluir()
            pausar()
        elif opcao == "6":
            opcao_usuarios()
            pausar()
        elif opcao == "7":
            opcao_estatisticas()
            pausar()
        elif opcao == "8":
            iniciar_servidor()
            break
        elif opcao == "0":
            print("Encerrando...")
            break
        else:
            print("Opção inválida!")
            pausar()


if __name__ == "__main__":
    main()